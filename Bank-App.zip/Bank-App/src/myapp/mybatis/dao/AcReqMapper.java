package myapp.mybatis.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import myapp.mybatis.modalclass.accountRequest;
import myapp.mybatis.util.MybatisUtil;

@Repository
public class AcReqMapper {

	public List<accountRequest> getAllAccount() {

		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		List<accountRequest> accounts = session.selectList("myapp.mybatis.dao.AcReqMapper.getAc");
		session.commit();
		session.close();
		return accounts;
	}

	public List<accountRequest> getAllTransactions(accountRequest param) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		List<accountRequest> Transaction = session.selectList("getTran", param);
		session.commit();
		session.close();
		return Transaction;
	}

	public void saveAccount(accountRequest acc) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		session.insert("insertAc", acc);
		session.commit();
		session.close();
	}

	public void rejectAccount(int custId) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		session.update("reject", custId);
		// session.delete("deleteAc",custId);
		session.commit();
		session.close();
	}

	public accountRequest findById(int custId) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		accountRequest account = session.selectOne("findBy", custId);

		session.commit();
		session.close();
		return account;
	}

	public void approveCust(int custId) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		session.update("approve", custId);
		List<accountRequest> list = session.selectList("track", custId);
		session.insert("InsertUsers", list.get(0));
		System.out.println(list.get(0).getTit());
		accountRequest field = (list.get(0));
		session.update("RegisteredInfo", field);
		session.commit();
		session.close();
	}

	public String getRol(accountRequest param2) {
		try {
			SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
			List<accountRequest> users = session.selectList("getRole", param2);
			String role = users.get(0).getRole();
			session.commit();
			session.close();
			return role;
		} catch (Exception e) {
			return null;
		}
	}

	public void newTransaction(accountRequest login) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		session.insert("insertTran", login);
		session.commit();
		session.close();
		// return ;
	}

	public List<accountRequest> getCust(accountRequest params) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		List<accountRequest> account = session.selectList("getCust", params);
		session.commit();
		session.close();
		return account;
	}

	public List<accountRequest> getId(String mailID) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		List<accountRequest> det = session.selectList("getID", mailID);
		session.commit();
		session.close();
		return det;
	}

	// public List<accountRequest> getCustTran(String mai)

	public List<accountRequest> getTrack(int id) {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		List<accountRequest> status = session.selectList("getTrack", id);
		session.commit();
		session.close();
		return status;
	}

	public List<accountRequest> approveAC() {
		SqlSession session = MybatisUtil.getSqlSessionFactory().openSession();
		List<accountRequest> accounts = session.selectList("myapp.mybatis.dao.AcReqMapper.approveReqs");
		session.commit();
		session.close();
		return accounts;
	}

}
