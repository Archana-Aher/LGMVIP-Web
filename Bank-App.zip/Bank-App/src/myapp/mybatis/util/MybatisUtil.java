package myapp.mybatis.util;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisUtil {
	
	
	private static SqlSessionFactory sessionFactory;
	public static SqlSessionFactory getSqlSessionFactory(){
		Reader reader;
		try {
			reader=Resources.getResourceAsReader("AccountReq.xml");
			//System.out.println(reader+" from reader");
			sessionFactory=new SqlSessionFactoryBuilder().build(reader,"acreq");
			//System.out.println(sessionFactory+" from reader");

		}
		catch(IOException e){
			e.printStackTrace();
		}
		return sessionFactory;
	}
}
