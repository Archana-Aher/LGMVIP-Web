package bankApp;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import myapp.mybatis.dao.AcReqMapper;
//import myapp.mybatis.dao.RegisteredInfo;
import myapp.mybatis.modalclass.accountRequest;

@Controller
public class HomeController {
	@Autowired
	AcReqMapper mapper;

	@RequestMapping("/")
	public String showpage() {

		return "index";
	}

	@RequestMapping("login")
	public String login() {
		return "login";
	}

	@RequestMapping("logout")
	public String logout(HttpSession session, HttpServletRequest request) {

		session.invalidate();
		return "index";
	}

	@RequestMapping("home1")
	public String home1() {
		return "index";
	}

	// ADMIN LOGIN AND PAGES HANDLING VALIDATION
	@RequestMapping("Adminlogin")
	public ModelAndView Adminlogin(@RequestParam("username") String username, @RequestParam("password") int password,
			HttpSession session) {
		accountRequest params = new accountRequest();
		params.setLname(username);
		params.setPhone(password);
//		
		accountRequest param2=new accountRequest();
		param2.setPassword(password);
		param2.setLogin_id(username);

		ModelAndView mav = new ModelAndView("CustomerDetails");
		ModelAndView mav2 = new ModelAndView("loginError");

		ModelAndView mav3 = new ModelAndView("AdminPage");

		mav.addObject("accountReqs", mapper.getCust(params));
		System.out.println(mapper.getRol(param2));

		try {
			if ((mapper.getRol(param2)).equals("cust")) {

				return mav;
			} else if ((mapper.getRol(param2)).equals("admin")) {
				return mav3;
			} else {
				return mav2;
			}
		} catch (Exception e) {
			return mav2;
		}
	}

	@RequestMapping("Adminlogin/admin")
	public ModelAndView admin() {
		ModelAndView mav = new ModelAndView("requests");
		mav.addObject("accountReqs", mapper.getAllAccount());
		return mav;
	}

	@RequestMapping("Adminlogin/approveRequests")
	public ModelAndView adminApprove() {
		ModelAndView mav = new ModelAndView("approveRequests");
		mav.addObject("accountReqs", mapper.approveAC());
		return mav;
	}

	@RequestMapping("Adminlogin/cal")
	public String adminCal() {
		return "adminCal";
	}

	@RequestMapping("Adminlogin/logout")
	public String adminLogout() {
		return "redirect:/logout";
	}
	
	@RequestMapping("Admin/logout")
	public String CustLogout() {
		return "redirect:/logout";
	}

	
	
	@RequestMapping("home")
	public ModelAndView showForm() {
		ModelAndView mav2 = new ModelAndView("error404");

		try{
		ModelAndView mav = new ModelAndView("CreateAccountForm");
		mav.addObject("acc", new accountRequest());
		return mav;
	}catch(Exception e) {
		return mav2;
	}
	}

	@RequestMapping("/registerSuccess")
	public String registerSuccess() {
		return "registerSuccess";
	}

	@RequestMapping("/saveProcess")
	public String saveProcess(@ModelAttribute("acc") accountRequest acc) {
		
			// System.out.println("Account "+acc);
			mapper.saveAccount(acc);
			return "redirect:/registerSuccess";
		
	}

	@RequestMapping("Admin/new")
	public ModelAndView Custnew() {
		ModelAndView mav = new ModelAndView("CustomerNewTransaction");
		mav.addObject("login", new accountRequest());
		return mav;
	}
	
//	@RequestMapping("Admin/Details")
//	public String details() {
//		return "redirect:/Adminlogin";
//	}

	@RequestMapping("Admin/add")
	public String add(@ModelAttribute("login") accountRequest login) {
		try {
			
			mapper.newTransaction(login);
			return "redirect:/Admin/new";
		}
		catch(Exception e) {
			return "invalidDetails";
		}

	}

	@RequestMapping("getAppid")
	public String getId() {
		return "getId";
	}

	@RequestMapping("check")
	public ModelAndView getPostid(@RequestParam("mailID") String mailID) {
		ModelAndView mav = new ModelAndView("getIdPost");
		mav.addObject("accountReqs", mapper.getId(mailID));
		return mav;
	}

	@RequestMapping("Admin/show")
	public String showTran() {
		// ModelAndView mav=new ModelAndView("CustomerTranDetails");
		// mav.addObject("accountReqs",mapper.getAllTransactions());
		return "showTransactionForm";
	}

	@RequestMapping("Admin/showTrans")
	public ModelAndView showTrans(@RequestParam("code") int code, @RequestParam("startdate") String startdate,
			@RequestParam("enddate") String enddate) {
		ModelAndView mav2 = new ModelAndView("loginError");

		accountRequest param = new accountRequest();
		param.setStartdate(startdate);
		param.setEnddate(enddate);
		param.setCode(code);
		try {
		ModelAndView mav = new ModelAndView("CustomerTranDetails");
		mav.addObject("accountReqs", mapper.getAllTransactions(param));
		return mav;
		}
		catch(Exception e) {
			return mav2;
		}
	}
//	
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public String errorhandleing() {
		return "redirect:/error400";
	}
	
	@RequestMapping("/rejectCustomer")
	public String rejectCust(@RequestParam("custid") int custId) {
		mapper.rejectAccount(custId);
		return "redirect:/Adminlogin/admin";
	}

	@RequestMapping("/updateCustomer")
	public ModelAndView updateCust(@RequestParam("custid") int custId) {

		ModelAndView mav = new ModelAndView("CreateAccountForm");
		accountRequest account = mapper.findById(custId);
		mav.addObject("acc", account);
		return mav;
	}

	@RequestMapping("/approveCustomer")
	public String approveCust(@RequestParam("custid") int custId) {
		mapper.approveCust(custId);
		return "redirect:/Adminlogin/admin";
	}

	@RequestMapping("about")
	public String show1() {
		return "aboutUs";
	}

	@RequestMapping("track")
	public String track() {
		return "track";
	}

	@RequestMapping("trackStatus")
	public ModelAndView TrackStatus(@RequestParam("id") int id) {
		ModelAndView mav = new ModelAndView("trackStatus");
		mav.addObject("accountReqs", mapper.getTrack(id));
		return mav;
	}

	@RequestMapping("faq")
	public String FAQ() {
		return "FAQ";
	}

	@RequestMapping("help")
	public String Help() {
		return "help";
	}

	@RequestMapping("Admin/cal")
	public String CustCal() {
		return "CustCalander";
	}

	@RequestMapping("Admin/help")
	public String CustHelp() {
		return "CustHelp";
	}

}
