package net.login.bean;

import java.io.Serializable;

public class MACbean implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String MACusername;
    private String MACpassword;

    public String getUsername() {
        return MACusername;
    }

    public void setUsername(String MACusername) {
        this.MACusername = MACusername;
    }

    public String getPassword() {
        return MACpassword;
    }

    public void setPassword(String MACpassword) {
        this.MACpassword = MACpassword;
    }
}