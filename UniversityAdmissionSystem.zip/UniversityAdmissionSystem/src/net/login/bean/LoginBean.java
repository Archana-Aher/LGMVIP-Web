package net.login.bean;

import java.io.Serializable;

public class LoginBean implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String user;
    private String pass;

    public String getUsername() {
        return user;
    }

    public void setUsername(String user) {
        this.user = user;
    }

    public String getPassword() {
        return pass;
    }

    public void setPassword(String pass) {
        this.pass = pass;
    }
}
