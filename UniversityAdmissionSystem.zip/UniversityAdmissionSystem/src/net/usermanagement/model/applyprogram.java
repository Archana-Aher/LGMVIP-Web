package net.usermanagement.model;

	import java.io.Serializable;

	public class applyprogram implements Serializable {
		    
		    private static final long serialVersionUID = 1L;
		    private String appname;
		    private String progName;
			public String getAppname() {
				return appname;
			}
			public void setAppname(String appname) {
				this.appname = appname;
			}
			public String getProgName() {
				return progName;
			}
			public void setProgName(String progName) {
				this.progName = progName;
			}
		    
		    
		    
	}