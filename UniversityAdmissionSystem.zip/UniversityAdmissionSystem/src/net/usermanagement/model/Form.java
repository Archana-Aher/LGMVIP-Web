package net.usermanagement.model;

import java.io.Serializable;

public class Form implements Serializable {
	    
	    private static final long serialVersionUID = 1L;
	    private String applicantname;
	    private String prgname;
	    private String emailid;
	    private String state;
	    
		public String getApplicantname() {
			return applicantname;
		}
		public void setApplicantname(String applicantname) {
			this.applicantname = applicantname;
		}
		public String getPrgname() {
			return prgname;
		}
		public void setPrgname(String prgname) {
			this.prgname = prgname;
		}
		public String getEmailid() {
			return emailid;
		}
		public void setEmailid(String emailid) {
			this.emailid = emailid;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
}

