package net.usermanagement.model;

	import java.io.Serializable;

	public class PrgSchedule implements Serializable {
		    
		    private static final long serialVersionUID = 1L;
		    private String prgscheduleid;
		    private String programmName;
		    private String Location;
		    private String Start_Date;
		    private String End_date;
		    private String sessionweek;
		    
			public String getPrgscheduleid() {
				return prgscheduleid;
			}
			public void setPrgscheduleid(String prgscheduleid) {
				this.prgscheduleid = prgscheduleid;
			}
			public String getProgrammName() {
				return programmName;
			}
			public void setProgrammName(String programmName) {
				this.programmName = programmName;
			}
			public String getLocation() {
				return Location;
			}
			public void setLocation(String location) {
				Location = location;
			}
			public String getStart_Date() {
				return Start_Date;
			}
			public void setStart_Date(String start_Date) {
				Start_Date = start_Date;
			}
			public String getEnd_date() {
				return End_date;
			}
			public void setEnd_date(String end_date) {
				End_date = end_date;
			}
			public String getSessionweek() {
				return sessionweek;
			}
			public void setSessionweek(String sessionweek) {
				this.sessionweek = sessionweek;
			}
		    
		    
		    
	}