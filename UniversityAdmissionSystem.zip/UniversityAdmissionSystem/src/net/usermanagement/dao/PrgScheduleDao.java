package net.usermanagement.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.usermanagement.model.PrgSchedule;

public class PrgScheduleDao {

    public int prggsche(PrgSchedule prgschedule) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO scheprg" +
            "  (schid, schname, schlocation, schstartdate, schenddate, schsession) VALUES " +
            " (?, ?, ?, ?,?, ?)";

        int result = 0;

        Class.forName("oracle.jdbc.driver.OracleDriver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:oracle:thin:@pgstrng1-01.oracle.db.principal.com:15080/pgstrng1","D555178","Sup69!$J");
        		PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            
            preparedStatement.setString(1, prgschedule.getPrgscheduleid());
            preparedStatement.setString(2, prgschedule.getProgrammName());
            preparedStatement.setString(3, prgschedule.getLocation());
            preparedStatement.setString(4, prgschedule.getStart_Date());
            preparedStatement.setString(5, prgschedule.getEnd_date());
            preparedStatement.setString(6, prgschedule.getSessionweek());
            
            System.out.println(preparedStatement);
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            
            printSQLException(e);
        }
        return result;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}