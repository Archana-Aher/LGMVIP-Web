package net.usermanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.usermanagement.model.Applicant;

public class ApplicantDao {

    public int registerApplicant(Applicant applicant) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO applicant" +
            "  (id, first_name, last_name, username, password, address, contact, schedule_id, Status, Interview) VALUES " +
            " (?, ?, ?, ?, ?,?,?,?,?,?)";

        int result = 0;

        Class.forName("oracle.jdbc.driver.OracleDriver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:oracle:thin:@pgstrng1-01.oracle.db.principal.com:15080/pgstrng1","D555178","Sup69!$J");

            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            preparedStatement.setInt(1, 1);
            preparedStatement.setString(2, applicant.getFirstName());
            preparedStatement.setString(3, applicant.getLastName());
            preparedStatement.setString(4, applicant.getUsername());
            preparedStatement.setString(5, applicant.getPassword());
            preparedStatement.setString(6, applicant.getAddress());
            preparedStatement.setString(7, applicant.getContact());
            preparedStatement.setString(8, applicant.getSchedule());
            preparedStatement.setString(9, applicant.getStatus());
            preparedStatement.setString(10, applicant.getInterview());

            System.out.println(preparedStatement);
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            
            printSQLException(e);
        }
        return result;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}