package net.usermanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import net.usermanagement.model.Form;

public class FormDao {

    public int registerForm(Form form) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO applicantform" +
            "  (name, prg, eid, status) VALUES " +
            " (?, ?, ?, ?)";

        int result = 0;

        Class.forName("oracle.jdbc.driver.OracleDriver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:oracle:thin:@pgstrng1-01.oracle.db.principal.com:15080/pgstrng1","D555178","Sup69!$J");
        		PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            
            preparedStatement.setString(1, form.getApplicantname());
            preparedStatement.setString(2, form.getPrgname());
            preparedStatement.setString(3, form.getEmailid());
            preparedStatement.setString(4, form.getState());
            
            System.out.println(preparedStatement);
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            
            printSQLException(e);
        }
        return result;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}