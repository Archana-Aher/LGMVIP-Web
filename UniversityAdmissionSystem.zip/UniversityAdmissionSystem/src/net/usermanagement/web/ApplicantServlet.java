package net.usermanagement.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.usermanagement.dao.ApplicantDao;
import net.usermanagement.model.Applicant;


@WebServlet("/online")
public class ApplicantServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ApplicantDao applicantDao;

    public void init() {
    	applicantDao = new ApplicantDao();
    }
   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String address = request.getParameter("address");
        String contact = request.getParameter("contact");
        String schedule = request.getParameter("schedule");
        String status = request.getParameter("status");
        String interview = request.getParameter("interview");

        Applicant applicant = new Applicant();
        applicant.setFirstName(firstName);
        applicant.setLastName(lastName);
        applicant.setUsername(username);
        applicant.setPassword(password);
        applicant.setContact(contact);
        applicant.setAddress(address);
        applicant.setSchedule(schedule);
        applicant.setStatus(status);
        applicant.setInterview(interview);

        try {
        	applicantDao.registerApplicant(applicant);
        } catch (Exception e) {
            
            e.printStackTrace();
        }

        response.sendRedirect("applicantdetails.jsp");
       
    }
}