package net.usermanagement.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.usermanagement.dao.ApplyPrgDao;
import net.usermanagement.model.applyprogram;


@WebServlet("/aaaa")
public class ApplyPrgServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ApplyPrgDao applydao;

    public void init() {
    	applydao = new ApplyPrgDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String appname = request.getParameter("appname");
        String progName = request.getParameter("progName");
        
        
        
        applyprogram applyPrg = new applyprogram();
        applyPrg.setAppname(appname);
        applyPrg.setProgName(progName);
    
        
        try {
        	applydao.courseapply(applyPrg);
        } catch (Exception e) {
            
            e.printStackTrace();
        }

        response.sendRedirect("applydetails.jsp");
       
    }
}