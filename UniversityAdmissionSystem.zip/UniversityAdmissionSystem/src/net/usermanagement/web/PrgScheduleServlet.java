package net.usermanagement.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.usermanagement.dao.PrgScheduleDao;
import net.usermanagement.model.PrgSchedule;


@WebServlet("/prgschedule")
public class PrgScheduleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private PrgScheduleDao prgscheduledao;

    public void init() {
    	prgscheduledao = new PrgScheduleDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String prgscheduleid = request.getParameter("prgscheduleid");
        String programmName = request.getParameter("programmName");
        String Location = request.getParameter("Location");
        String Start_Date = request.getParameter("Start_Date");
        String End_date = request.getParameter("End_date");
        String sessionweek = request.getParameter("sessionweek");
        
        
        PrgSchedule prgschedule = new PrgSchedule();
        prgschedule.setPrgscheduleid(prgscheduleid);
        prgschedule.setProgrammName(programmName);
        prgschedule.setLocation(Location);
        prgschedule.setStart_Date(Start_Date);
        prgschedule.setEnd_date(End_date);
        prgschedule.setSessionweek(sessionweek);
        
        try {
        	prgscheduledao.prggsche(prgschedule);
        } catch (Exception e) {
            
            e.printStackTrace();
        }

        response.sendRedirect("scheduledetails.jsp");
       
    }
}