package net.usermanagement.web;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.login.bean.MACbean;
import net.usermanagement.dao.MACLoginDao;



@WebServlet("/MAClogin")
public class MACLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MACLoginDao MACloginDao;

    public void init() {
        MACloginDao = new MACLoginDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String MACusername = request.getParameter("MACusername");
        String MACpassword = request.getParameter("MACpassword");
        MACbean macloginBean = new MACbean();
        macloginBean.setUsername(MACusername);
        macloginBean.setPassword(MACpassword);

        try {
        	MACloginDao.validate(macloginBean);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        response.sendRedirect("MACLoginsuccess.jsp");
    }
}