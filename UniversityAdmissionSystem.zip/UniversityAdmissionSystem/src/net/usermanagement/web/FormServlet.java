package net.usermanagement.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.usermanagement.dao.FormDao;
import net.usermanagement.model.Form;


@WebServlet("/formapplicant")
public class FormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private FormDao formDao;

    public void init() {
    	formDao = new FormDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String applicantname = request.getParameter("applicantname");
        String prgname = request.getParameter("prgname");
        String emailid = request.getParameter("emailid");
        String state = request.getParameter("state");
        
        
        Form form = new Form();
        form.setApplicantname(applicantname);
        form.setPrgname(prgname);
        form.setEmailid(emailid);
        form.setState(state);
        
        try {
        	formDao.registerForm(form);
        } catch (Exception e) {
            
            e.printStackTrace();
        }

        response.sendRedirect("formdetails.jsp");
       
    }
}