package com.springmvc.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.dao.UserDao;
import com.springmvc.model.User;

@Controller
@RequestMapping(value="/")
public class HomeController {
	
	@Autowired
    private UserDao udao;

	@RequestMapping(value="user")
	public String showUser(@RequestParam("username") String username, Model model) {
		User user = udao.findUser(username);
		model.addAttribute("user", user);
		System.out.println(udao.findUser(username));
		return "display";
	}
	
    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("user");
        return "login";
    }

    @PostMapping("/login")
    public String processLoginForm(@ModelAttribute("user") User User, HttpSession session) {
            return "redirect:/home";
    }
    
    /*@GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/admin/login";
    }
		
	}*/

}
