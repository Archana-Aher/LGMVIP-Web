package com.springmvc.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.dao.UserDao;
import com.springmvc.model.User;

@Controller
public class UserController 
{
	@Autowired
	UserDao udao;
	
	
	@RequestMapping(value="/userList")
	 public String showList(ModelMap model) { 
		List<User> mylist=udao.viewAll(); 
		model.addAttribute("ulist", mylist);
	  System.out.println("The Elements: "+ mylist.size());  
	  Iterator<User> it=mylist.iterator();
	  while(it.hasNext())
		  System.out.println(it.next());
	  return "userList";
	  } 
	
	@RequestMapping(value="user")
	public String showUser(@RequestParam("username") String username, Model model) {
		User user = udao.findUser(username);
		model.addAttribute("user", user);
		System.out.println(udao.findUser(username));
		return "display";
	}
}
