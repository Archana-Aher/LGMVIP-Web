package com.springmvc.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvc.mapper.AirportMapper;
import com.springmvc.mapper.UserMapper;
import com.springmvc.model.Airport;

@Repository
public abstract class AirportDaoImpl implements AirportDao {

    @Autowired
    private SqlSession sqlSession;

    public void setSqlSession(SqlSession sqlSession) {
        this.sqlSession = sqlSession;
    }
    
    @Autowired
	private AirportMapper mapper;

    @Override
    public List<Airport> getAllAirports() {
        AirportMapper airportMapper = sqlSession.getMapper(AirportMapper.class);
        return mapper.getAllAirport();
    }
}