package com.springmvc.dao;

import java.util.List;

import com.springmvc.model.User;

public interface UserDao 
{
	User findUser(String username);
	List<User> viewAll();
}
