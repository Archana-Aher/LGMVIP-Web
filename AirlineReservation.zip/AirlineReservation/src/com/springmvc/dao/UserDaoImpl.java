package com.springmvc.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.springmvc.mapper.UserMapper;
import com.springmvc.model.User;

@Component
public class UserDaoImpl implements UserDao 
{
	@Autowired
	 private SqlSessionTemplate sqlSessiontemplate; 
	@Autowired
	private UserMapper mapper;
	
	
	@Override
	public List<User> viewAll() {
		//System.out.println("connected");
		return mapper.getAll();
	}


	@Override
	public User findUser(String username) {
		return mapper.getUser(username);
	}

}







