package com.springmvc.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvc.model.Flight;

@Repository
public abstract class FlightDaoImpl implements FlightDao {

    @Autowired
    private SqlSession sqlSession;

    public void setSqlSession(SqlSession sqlSession) {
        this.sqlSession = sqlSession;
    }

    @Override
    public void insertFlight(Flight flight) {
        sqlSession.insert("FlightMapper.insertFlight", flight);
    }

    @Override
    public void updateFlight(Flight flight) {
        sqlSession.update("FlightMapper.updateFlight", flight);
    }

    @Override
    public void deleteFlight(int id) {
        sqlSession.delete("FlightMapper.deleteFlight", id);
    }

    @Override
    public Flight getFlightById(int id) {
        return sqlSession.selectOne("FlightMapper.getFlightById", id);
    }

    @Override
    public List<Flight> getAllFlights() {
        return sqlSession.selectList("FlightMapper.getAllFlights");
    }
}
