package com.springmvc.dao;

import java.util.List;

import com.springmvc.model.Flight;

public interface FlightDao {
	public void insertFlight(Flight flight);
    public void updateFlight(Flight flight);
    public void deleteFlight(int id);
    public Flight getFlightById(int id);
    public List<Flight> getAllFlights();

}
