package com.springmvc.dao;

import java.util.List;

import com.springmvc.model.Airport;

public interface AirportDao {
	
    public List<Airport> getAllAirports();

}
