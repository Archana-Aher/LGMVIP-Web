package com.springmvc.mapper;
import java.util.List;

import org.apache.ibatis.annotations.*;

import com.springmvc.model.User;

class UserSqlProvider{
	public String findByUsername(String username) {
		return "select * from users where username='"+username+"'";
	}
}

public interface UserMapper
{
   final String getAll="select * from users";
   final String getUser="select * from users where username=#{username}";

   @Select(getAll)
   @SelectProvider(type=UserSqlProvider.class, method="findByUsername")
   @Results(value = {
      @Result(property = "username", column = "USERNAME"),
      @Result(property = "password", column = "PASSWORD"),
      @Result(property = "role", column = "ROLE"),
      @Result(property = "mobile_no", column = "MOBILE_NO"),
   })

   List<User> getAll();
   User getUser(String username);
   
}
