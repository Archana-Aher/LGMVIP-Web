package com.springmvc.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.springmvc.model.Airport;
import com.springmvc.model.User;

public interface AirportMapper {
	
	final String getAll="select * from airport";
	
	@Select(getAll)
		/*@Results(value = {
				@Result(property = "airportname", column = "airportname"),
				@Result(property = "abbreviation", column = "abbreviation"),
				@Result(property = "location", column = "location"),
		})*/
		List<Airport> getAllAirport();
	

}
