package com.springmvc.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.springmvc.model.Flight;

public interface FlightMapper {
	
	final String getAll = "select * from flightinfo";
	final String getALL = "select flightno, airline, dep_city, to_char (dep_date, 'DD-MM-YYYY') as dep_date, to_char(dep_tise)";
	final String insert = "INSERT INTO flight info (airline,dep_city, dep_date, dep time, arr_city, arr_date, arr_time, firstseats";
	
	final String update = "update flight info set airline=#(airline), dep_city=#(dep_city), arr_city=#{arr_city), firstseats #(firstseats)";
	final String delete = "delete from flight info where flightno=#(flightno)";

	@Select(getALL)
	List<Flight> getAllFlights();

	@Insert(insert)
	void insert(Flight flight);

	@Update(update)
	void update(Flight flight);

	@Delete(delete)
	void delete(int flightno);
}
